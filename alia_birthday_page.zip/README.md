# Alia's Birthday Page

A responsive birthday page using the five photos supplied in the chat.

## View it
Open `index.html` in a browser. Keep the `images` folder beside it.

## Publish it free
1. Create a new repository on GitHub (for example `alia-birthday`).
2. Upload `index.html` and the whole `images` folder.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the link.

The page is static; it does not collect personal information.
